#Sean Blanchard
#4/27/2021
#COMP429- PROJ03


import socket
from .packet import Packet
from .common import *
from .controlblock import ControlBlock
from .coutput import Coutput
from .cinput import Cinput
import logging

class Socket:
    def __init__(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.cb = ControlBlock()
        self.cb.sock = sock
        self.coutput = Coutput(self.cb)
        self.cinput = Cinput(self.cb)
        

    ##################################################################
    # API Calls - used by the client and server.
    # All your hard work is hidden by these few functions.
    # Let's take a moment to thank everyone who has worked on
    # implementing TCP for our respective operating systems.
    ##################################################################
    #help us get a 3 way handshake
    def connect(self, address):
        print("connect!")

        self.cb.dst = address

        #send a Syn
        self.coutput.cirt_output()

        # Look for Synack
        packet, address = self.cinput.cirt_input()

        #Check for syanack to proceed
        if packet.is_synack() and packet.ackno == self.cb.seqno +1:
            logging.info("Received SYN/ACK")
            logging.info("ESTABLISHED")
            self.cb.state = ESTABLISHED
            self.coutput.cirt_output()

            self.cb.seqno = +1
            self.cb.ackno = packet.seqno + 1

        #Send syn message
        #listen to synack (while) -> loop on state of control block
        #once state established you will send ack



    def listen(self, port):
        addr = ('127.0.0.1', port)
        self.cb.sock.bind(addr)
        self.cb.state = LISTEN


    def accept(self):
        print("accept a connection!")
        packet, address = self.cinput.cirt_input()
        if packet.is_syn():
            logging.info("Received SYN packet")
            print("accept connection!")
            #Send the syn and acknowledgment
            self.cb.state = SYN_RECV
            self.cb.dst = address

            self.cb.seqno = S_ISN
            self.cb.ackno = packet.seqno +1
            self.coutput.cirt_output()
            # wait for acknowledgement
            packet, address = self.cinput.cirt_input()
            if packet.is_ack() and packet.ackno == self.cb.seqno +1:
            #if packet.is_ack():
                logging.info("ESTABLISHED")
                self.cb.state = ESTABLISHED


    def send(self, data):
        print("send some data!")
        self.coutput.cirt_output(data)
        self.cb.seqno += len(data)
        # wait for ack before being able to send more data


    def recv(self, size):
        print("receive some data!")
        packet, address = self.cinput.cirt_input()


    def close(self):
        print("we done here")
        # if the state is already closed, exit out
        if self.cb.state == CLOSED:
            return
        self.cb.state = FIN_WAIT_1
        logging.info(f"State = {self.cb.state}")
        self.cb.ackno = 0
        self.coutput.cirt_output()
        packet, address = self.cinput.cirt_input()
        if packet.is_ack() and packet.ackno == 1:
            # FIN/ACK
            self.cb.state = FIN_WAIT_2
            logging.info(f"State = {self.cb.state}")
            # wait
            packet, address = self.cinput.cirt_input()
            self.cb.state = TIME_WAIT
            self.cb.ackno = packet.ackno + 1
            self.coutput.cirt_output()
            self.cb.state = CLOSED
            logging.info("CLOSED")
